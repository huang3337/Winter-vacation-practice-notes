#include <REGX52.H>
#include "Delay.h"
#include "MatrixKey.h"
#include "Nixie.h"

unsigned char KeyNum;

void main()
{

	while(1)
	{
		KeyNum=MatrixKey();

		if(KeyNum < 10)
		{
			Nixie(1,0);
			Nixie(2,KeyNum);
		}
		else
		{
			Nixie(1,KeyNum/10);
			Nixie(2,KeyNum%10);
		}
		
	}
}
