#include <REGX52.H>
#include "Delay.h"
#include "MatrixKey.h"
#include "Nixie.h"

unsigned char KeyNum;

void main()
{

	while(1)
	{
		KeyNum=MatrixKey();

		if(KeyNum < 10)
		{
			Nixie(1, KeyNum%10);
		}
		else if(KeyNum == 10)Nixie(1, 10);
		else if(KeyNum == 11)Nixie(1, 11);
		else if(KeyNum == 12)Nixie(1, 12);
		else if(KeyNum == 13)Nixie(1, 13);
		else if(KeyNum == 14)Nixie(1, 14);
		else if(KeyNum == 15)Nixie(1, 15);
		else if(KeyNum == 16)Nixie(1, 16);
	}
}
