#include <REGX52.H>


void main(void)
{
	P2 = 0xFE;

	
}