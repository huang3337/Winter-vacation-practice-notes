#ifndef __NIXIE_H__
#define __NIXIE_H__

void Nixie();
void Show_SetState(unsigned char mode, unsigned char* nums);

extern unsigned char NixieTable[];
extern unsigned char Display_Buf[];
						 
#endif