#include <REGX52.H>
#include "Delay.h"
#include "MatrixKey.h"
#include "Nixie.h"

unsigned char Password[4] = {1,2,3,4};//预设密码
unsigned char Input_Buf[4] = {22,22,22,22};//输入缓存
unsigned char Count = 0;//当前输入到了第几位

	
void main()
{
	unsigned char key_num = 0;
	unsigned char i;
	unsigned char is_correct = 1;
	
	
	while(1)
	{
		key_num = MatrixKey();
		
		Nixie();
		if(key_num)
		{
			//输入数字0~9
			if(key_num<10)
			{
				if(Count<4)
				{
					Input_Buf[Count] = key_num%10;
					Count++;
					Show_SetState(0, Input_Buf);
				}
			}
			//确认键，键值为11
			else if(key_num == 11)
			{
				if(Count == 4)//保证已经输满了4位
				{
					is_correct = 1;
					//比对数组
					for(i=0;i<4;i++)
					{
						if(Input_Buf[i] != Password[i])
						{
							is_correct = 0;
							break;
						}
					}
					if(is_correct)
					{
						Show_SetState(1, 0);
					}
					else
					{
						Show_SetState(2, 0);
					}
					for(i=0;i<200;i++)
					{
						Nixie();
						Delay(10);
					}
					Count = 0;
					for(i=0;i<4;i++)
						Input_Buf[i] = 22;
					Show_SetState(0, Input_Buf);
				}
			}
			//清除键,键值为12
			else if(key_num == 12)
			{
				Count = 0;
				for(i=0;i<4;i++)
					Input_Buf[i] = 22;
				Show_SetState(0, Input_Buf);
			}
		}
		key_num = 0;
	}
}
