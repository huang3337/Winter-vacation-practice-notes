#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"
#include "Nixie.h"

unsigned char num;

void main()
{
	Timer0_Init();
	
	while(1)
	{
		Nixie(1,num/10);
		Nixie(2,num%10);
	}
}

void Timer0_Routine() interrupt 1
{
	static unsigned int T0Count;
	TL0 = 0x66;				//设置定时初始值
	TH0 = 0xFC;				//设置定时初始值
	T0Count++;
	if(T0Count>=1000)	//定时器分频，1s
	{
		T0Count=0;
		num++;			//1秒到，num自增
		if(num>99)
		{
			num=0;
		}
	}
}
