#include <REGX52.H>
#include <intrins.h>

void Delay(unsigned int xms)		//@11.0592MHz
{
	unsigned int z;
	for(z = 0; z < xms; z++)
	{
		unsigned char i, j;

		_nop_();
		i = 2;
		j = 199;
		do
		{
		  while (--j);
		} while (--i);
	}
}

void main(void)
{
	while(1)
	{
		if(P3_1 == 0)
		{
			Delay(20);
			while(P3_1 == 0);
			Delay(20);
			
			P2_0 = ~P2_0;
		}
	}
}