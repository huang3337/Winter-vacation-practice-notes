#include <REGX52.H>
#include <string.h> 
#include "Delay.h"
#include "UART.h"

char Rcv_Buf[16]; // 接收缓冲区
unsigned char Buf_Index = 0;
bit Cmd_R = 0;   // 标志位：1表示收到了一条完整指令

void main()
{
    UART_Init();
    P2 = 0xFF; // 默认灭

    while(1)
    {
        //循环发送
        UART_SendString("Hello 51!\r\n");

        //处理指令
        if(Cmd_R) 
        {
            if(strcmp(Rcv_Buf, "LED_ON") == 0)
            {
                P2 = 0x00; // 点亮
            }
            else if(strcmp(Rcv_Buf, "LED_OFF") == 0)
            {
                P2 = 0xFF; // 熄灭
            }

            // 清理缓冲区，准备接收下一条
            memset(Rcv_Buf, 0, sizeof(Rcv_Buf));
            Buf_Index = 0;
            Cmd_R = 0;
        }

        Delay(1000);
    }
}

void UART_Routine() interrupt 4
{
    if(RI == 1)
    {
        char res = SBUF;
        RI = 0;

        //判断是否收到换行符 \n 或 \r 或 空格 作为结束标志
        if(res == '\n' || res == '\r' || res == ' ')
        {
            if(Buf_Index > 0) // 如果缓冲区有数据
            {
                Rcv_Buf[Buf_Index] = '\0'; // 结束符
                Cmd_R = 1;
            }
        }
        else
        {
            if(Buf_Index < 15) // 防止溢出
            {
                Rcv_Buf[Buf_Index++] = res;
            }
        }
    }
}