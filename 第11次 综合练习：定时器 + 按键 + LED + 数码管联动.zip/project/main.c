#include <REGX52.H>
#include "Timer0.h"
#include "Nixie.h"
#include "Delay.h"

sbit KEY_START = P3^1; // 定义启停按键
sbit LED_FLAG  = P2^7; // 定义指示灯

unsigned char Counter = 0;     // 计数值 0-99
bit IsRunning = 0;             // 运行标志位 (0停止, 1运行)
unsigned char ScanPos = 0;     // 扫描位置索引

void main()
{
    Timer0_Init();
    
    IsRunning = 0;
    LED_FLAG = 1; // 1灭，0亮
    
    while(1)
    {
        if(KEY_START == 0)
        {
            Delay(20);
            if(KEY_START == 0)
            {
                IsRunning = !IsRunning;
                
                if(IsRunning) LED_FLAG = 0; // 亮
                else          LED_FLAG = 1; // 灭
                
                while(KEY_START == 0); // 等待松手
            }
        }
    }
}

void Timer0_Routine() interrupt 1
{
    static unsigned int T0Count = 0;
    
    //重装载初值 (保持1ms周期)
    TL0 = 0x66;
    TH0 = 0xFC;

    if(ScanPos == 0)
    {
        Nixie(1, Counter / 10); // 显示十位
        ScanPos = 1;
    }
    else
    {
        Nixie(2, Counter % 10); // 显示个位
        ScanPos = 0;
    }
    
    if(IsRunning)
    {
        T0Count++;
        if(T0Count >= 1000) // 1000ms = 1秒
        {
            T0Count = 0;
            Counter++;
            if(Counter > 99)
            {
                Counter = 0;
            }
        }
    }
}